package name.modid.client

import net.fabricmc.api.ClientModInitializer

object TregModClient : ClientModInitializer {
	override fun onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}